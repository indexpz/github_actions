<section class="not-found">
	<p><?php esc_html_e('No results were found for the requested page.', 'alekids');?></p>
</section>