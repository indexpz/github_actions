<?php if ( is_active_sidebar( 'main-sidebar' ) ) { ?>
    <aside class="sidebar cf">
        <?php dynamic_sidebar( 'main-sidebar' ); ?>
    </aside>
<?php } ?>